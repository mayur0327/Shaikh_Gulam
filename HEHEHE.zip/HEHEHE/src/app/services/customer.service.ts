import { Injectable } from '@angular/core';
import { CustomerModel } from '../models/customer';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  custArr: CustomerModel[];
  constructor(private routes:Router) { 
    this.custArr=[];

  }
  add(customer: CustomerModel) {
    customer.customerId = Math.floor(Math.random() * 500);
    this.custArr.push(customer);
    this.routes.navigate(['/display']);
  }

  getcustomers() {
    return this.custArr;
  }

  edit(id: number) {
    return this.custArr.find(x => x.customerId == id);
  }

  delete(index: number) {
    this.custArr.splice(index, 1);
  }
  searchCust(id: number) {
    var result = this.custArr.find(x => x.customerId == id);
    if (result == null)
      return null; //if not found
    else
      return result; //if found then store it
  }

  sortCust() {
    this.custArr.sort((a, b) => a.customerSalary > b.customerSalary ? 1 : ((a.customerSalary < b.customerSalary) ? -1 : 0));
    return this.custArr;
  }

  sortCustByName() {
    this.custArr.sort((a, b) => a.customerName > b.customerName ? 1 : ((a.customerName < b.customerName) ? -1 : 0));
    return this.custArr;
  }

  sortCustById() {
    this.custArr.sort((a, b) => a.customerId > b.customerId ? 1 : ((a.customerId < b.customerId) ? -1 : 0));
    return this.custArr;
  }


}
