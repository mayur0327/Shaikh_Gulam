import { Component, OnInit, Input , Output, EventEmitter} from '@angular/core';
import { CustomerModel } from '../models/customer';
import {CustomerService} from '../services/customer.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  @Input() customer: CustomerModel;

  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();
  
  
  constructor(private custService:CustomerService){ 
    this.customer = new CustomerModel();
  }
  add() {
    this.custService.add(this.customer);
    this.customer = new CustomerModel();
  }
  update()
  {
    this.isEditing = false;
    this.customer = new CustomerModel();
    this.edited.emit();
  }
  
  ngOnInit() {
  }


}
