import { BrowserModule } from '@angular/platform-browser';
import { NgModule ,Component } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { SearchComponent } from './search/search.component';
import { DisplayComponent } from './display/display.component';
import {RouterModule, Routes} from '@angular/router';


const routes:Routes = [
  {path:'', redirectTo: '',pathMatch : 'full'},
  {path:'register',component:RegisterComponent},
  {path:'display',component:DisplayComponent},
  {path:'search',component:SearchComponent},
  {path:'**', redirectTo: '/register', pathMatch : 'full'}

];

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    SearchComponent,
    DisplayComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(routes),FormsModule
  ],
  exports: [RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
