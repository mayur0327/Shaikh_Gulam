export class CustomerModel{

    public customerId:number;
    public customerName:String;
    public customerGender:String;
    public customerDepartment:String;
    public customerSalary:number;

}