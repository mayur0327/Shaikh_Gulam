import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../models/customer';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  custArr:CustomerModel[];
  customerToEdit:CustomerModel;
  isEditing:boolean;

  constructor(private custService:CustomerService) { 
    this.custArr=[];
    this.customerToEdit= new CustomerModel;
    
  }


  ngOnInit() {
    this.custArr = this.custService.getcustomers();
  }

  edit(id:number)
  {
    this.isEditing = true;
    this.customerToEdit = this.custService.edit(id);
  }

  sortEmp()
  {
    this.custService.sortCust();
  }
  sortByName(){
    this.custService.sortCustByName();
  }
  sortById(){
    this.custService.sortCustById();
  }

  delete(index: number) {
   this.custService.delete(index);
  }


}
